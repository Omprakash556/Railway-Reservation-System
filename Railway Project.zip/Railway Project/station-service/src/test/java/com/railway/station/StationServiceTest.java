package com.railway.station;

import com.railway.station.entity.Station;
import com.railway.station.exception.StationNotFoundException;
import com.railway.station.repository.StationRepository;
import com.railway.station.service.StationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StationServiceTest {

    @InjectMocks
    private StationService stationService;

    @Mock
    private StationRepository stationRepository;

    private Station station;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        station = new Station();
        station.setId(1L);
        station.setStationCode("MUM");
        station.setStationName("Mumbai Central");
    }

    @Test
    void testAddStation() {
        when(stationRepository.save(any(Station.class))).thenReturn(station);

        ResponseEntity<Station> response = stationService.addStation(station);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("MUM", response.getBody().getStationCode());
        verify(stationRepository, times(1)).save(station);
    }

    @Test
    void testGetAllStations() {
        List<Station> stations = List.of(station);
        when(stationRepository.findAll()).thenReturn(stations);

        ResponseEntity<List<Station>> response = stationService.getAllStations();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(stationRepository, times(1)).findAll();
    }

    @Test
    void testGetStationByCode_Success() {
        when(stationRepository.findByStationCode("MUM")).thenReturn(Optional.of(station));

        Optional<Station> result = stationService.getStationByCode("MUM");

        assertTrue(result.isPresent());
        assertEquals("MUM", result.get().getStationCode());
    }

    @Test
    void testGetStationByCode_NotFound() {
        when(stationRepository.findByStationCode("XYZ")).thenReturn(Optional.empty());

        assertThrows(StationNotFoundException.class, () -> stationService.getStationByCode("XYZ"));
    }

    @Test
    void testGetStationById_Success() {
        when(stationRepository.findById(1L)).thenReturn(Optional.of(station));

        Optional<Station> result = stationService.getStationById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getId());
    }

    @Test
    void testGetStationById_NotFound() {
        when(stationRepository.findById(2L)).thenReturn(Optional.empty());

        assertThrows(StationNotFoundException.class, () -> stationService.getStationById(2L));
    }

    @Test
    void testDeleteById_Success() {
        when(stationRepository.findById(1L)).thenReturn(Optional.of(station));
        doNothing().when(stationRepository).deleteById(1L);

        ResponseEntity<String> response = stationService.deleteById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Deleted Successfully", response.getBody());
        verify(stationRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteById_NotFound() {
        when(stationRepository.findById(2L)).thenReturn(Optional.empty());

        assertThrows(StationNotFoundException.class, () -> stationService.deleteById(2L));
    }
}
