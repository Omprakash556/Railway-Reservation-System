package com.railway.station.controller;

import com.railway.station.entity.Station;
import com.railway.station.service.StationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/station")
@Tag(name = "Station Controller", description = "Add Station, Get all station, Get station by code, Get station by id, Delete station by id")
public class StationController {

    private static final Logger logger = LoggerFactory.getLogger(StationController.class);

    @Autowired
    private StationService stationService;

    @PostMapping
    @Operation(summary = "API for add station")
    public ResponseEntity<Station> addStation(@RequestBody Station station){
        logger.info("Adding station: {}", station.getStationName());
        return stationService.addStation(station);
    }

    @GetMapping
    @Operation(summary = "get all station")
    public ResponseEntity<List<Station>> getAllStations(){
        logger.info("Fetching all stations");
        return stationService.getAllStations();
    }

    @GetMapping("/code/{code}")
    @Operation(summary = "API for get station by code")
    public Optional<Station> getStationByCode(@PathVariable String code){
        logger.info("Fetching station by code: {}", code);
        return stationService.getStationByCode(code);
    }

    @GetMapping("/id/{id}")
    @Operation(summary = "API for get station by id")
    public Optional<Station> getStationById(@PathVariable Long id){
        logger.info("Fetching station by ID: {}", id);
        return stationService.getStationById(id);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "API for delete station by id")
    public ResponseEntity<?> deleteStationById(@PathVariable Long id){
        logger.info("Deleting station with ID: {}", id);
        return stationService.deleteById(id);
    }
}
