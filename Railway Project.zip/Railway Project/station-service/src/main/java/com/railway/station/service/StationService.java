package com.railway.station.service;

import com.railway.station.entity.Station;
import com.railway.station.exception.StationNotFoundException;
import com.railway.station.repository.StationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StationService {

    private static final Logger logger = LoggerFactory.getLogger(StationService.class);

    @Autowired
    private StationRepository stationRepository;

    public ResponseEntity<Station> addStation(Station station){
        logger.debug("Saving station: {}", station.getStationName());
        Station saved = stationRepository.save(station);
        logger.info("Station saved: {}", saved.getStationCode());
        return new ResponseEntity<>(saved, HttpStatus.OK);
    }

    public ResponseEntity<List<Station>> getAllStations(){
        logger.debug("Fetching all stations from DB");
        List<Station> allStations = stationRepository.findAll();
        return new ResponseEntity<>(allStations, HttpStatus.OK);
    }

    public Optional<Station> getStationByCode(String stationCode){
        logger.debug("Searching station by code: {}", stationCode);
        return Optional.ofNullable(
                stationRepository.findByStationCode(stationCode)
                        .orElseThrow(() -> new StationNotFoundException("Station not found with code: " + stationCode))
        );
    }

    public Optional<Station> getStationById(Long id){
        logger.debug("Searching station by ID: {}", id);
        return Optional.ofNullable(
                stationRepository.findById(id)
                        .orElseThrow(() -> new StationNotFoundException("Station not found with ID: " + id))
        );
    }

    public ResponseEntity<String> deleteById(Long id){
        logger.info("Deleting station with ID: {}", id);
        Station station = stationRepository.findById(id)
                .orElseThrow(() -> new StationNotFoundException("Station not found with ID: " + id));
        stationRepository.deleteById(id);
        return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
    }
}
