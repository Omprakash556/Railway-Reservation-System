package com.railway.user;

import com.railway.user.entity.User;
import com.railway.user.exception.InvalidCredentialsException;
import com.railway.user.exception.UserNotFoundException;
import com.railway.user.repository.UserRepository;
import com.railway.user.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private BCryptPasswordEncoder passwordEncoder;

    @InjectMocks
    private UserService userService;

    @Test
    public void testRegisterUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("plainpassword");

        when(passwordEncoder.encode("plainpassword")).thenReturn("encryptedPassword");
        when(userRepository.save(any(User.class))).thenReturn(user);

        User savedUser = userService.registerUser(user);

        assertNotNull(savedUser);
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    public void testLoginUser_Success() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("encryptedPassword");

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("plainpassword", "encryptedPassword")).thenReturn(true);

        User result = userService.loginUser("testuser", "plainpassword");

        assertNotNull(result);
        assertEquals("testuser", result.getUsername());
    }

    @Test
    public void testLoginUser_UserNotFound() {
        when(userRepository.findByUsername("wronguser")).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> {
            userService.loginUser("wronguser", "anyPassword");
        });
    }

    @Test
    public void testLoginUser_InvalidPassword() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("encryptedPassword");

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("wrongPassword", "encryptedPassword")).thenReturn(false);

        assertThrows(InvalidCredentialsException.class, () -> {
            userService.loginUser("testuser", "wrongPassword");
        });
    }
}
