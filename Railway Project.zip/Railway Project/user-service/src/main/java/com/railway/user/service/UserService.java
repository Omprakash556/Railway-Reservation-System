package com.railway.user.service;

import com.railway.user.entity.User;
import com.railway.user.exception.InvalidCredentialsException;
import com.railway.user.exception.UserNotFoundException;
import com.railway.user.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class  UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public User registerUser(User user) {
        logger.debug("Encrypting password for user: {}", user.getEmail());
        String encryptedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encryptedPassword);
        User savedUser = userRepository.save(user);
        logger.info("User registered with email: {}", savedUser.getEmail());
        return savedUser;
    }

    public User loginUser(String username, String password) {
        logger.debug("Attempting login for username: {}", username);
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User not found with username: " + username));

        boolean match = passwordEncoder.matches(password, user.getPassword());
        logger.debug("Password match for username {}: {}", username, match);

        if (!match) {
            throw new InvalidCredentialsException("Invalid password");
        }

        return user;
    }
}
