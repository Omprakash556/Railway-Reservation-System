package com.railway.user.controller;

import com.railway.user.entity.User;
import com.railway.user.security.JWTUtil;
import com.railway.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/users")
@Tag(name = "User Controller", description = "Users can register and login")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private JWTUtil jwtUtil;

    @PostMapping("/register")
    @Operation(summary = "API for user registration")
    public ResponseEntity<User> register(@RequestBody User user) {
        logger.info("Registering user with email: {}", user.getEmail());
        return ResponseEntity.ok(userService.registerUser(user));
    }

    @PostMapping("/login")
    @Operation(summary = "API for user login")
    public ResponseEntity<String> login(@RequestParam String username, @RequestParam String password) {
        logger.info("Login attempt for username: {}", username);
        User user = userService.loginUser(username, password);
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole());
        return ResponseEntity.ok(token);

    }
}
