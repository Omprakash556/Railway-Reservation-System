package com.railway.payment.service;

import com.railway.payment.dto.PaymentRequest;
import com.railway.payment.dto.PaymentResponse;
import com.railway.payment.model.PaymentInfo;
import com.railway.payment.repository.PaymentInfoRepository;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.UUID;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;

@Service
public class PaymentService {

    @Autowired
    private PaymentInfoRepository paymentInfoRepository;

    public String createCheckoutSession(PaymentRequest request) throws StripeException, InterruptedException {
        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:8085/api/payments/success")
                .setCancelUrl("http://localhost:8085/api/payments/cancel")
                .addLineItem(
                        SessionCreateParams.LineItem.builder()
                                .setQuantity(1L)
                                .setPriceData(
                                        SessionCreateParams.LineItem.PriceData.builder()
                                                .setCurrency(request.getCurrency())
                                                .setUnitAmount(request.getAmount()) // amount in cents
                                                .setProductData(
                                                        SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                .setName("Ticket Payment")
                                                                .build()
                                                )
                                                .build()
                                )
                                .build()
                )
                .setCustomerEmail(request.getEmail())
                .build();

        Session session = Session.create(params);
        String sessionId = session.getId();

        System.out.println("Payment URL: " + session.getUrl());
        System.out.println("Waiting for user to complete payment...");

        String paymentIntentId = waitForPaymentIntent(sessionId);
        if (paymentIntentId == null) {
            return "PaymentIntent not created in time.";
        }

        String status = waitForPaymentStatus(paymentIntentId);

        if(status.equalsIgnoreCase("succeeded")){
            PaymentInfo info = new PaymentInfo();
            info.setEmail(request.getEmail());
            info.setAmount(request.getAmount());
            info.setCurrency(request.getCurrency());
            info.setPaymentStatus(status);
            info.setStripePaymentIntentId(paymentIntentId);
            info.setPaymentDate(LocalDateTime.now());

            paymentInfoRepository.save(info);
        }

        return status;
    }

    private String waitForPaymentIntent(String sessionId) throws InterruptedException, StripeException {
        for (int i = 0; i < 30; i++) { // Poll for up to 150 seconds
            Session session = Session.retrieve(sessionId);
            String paymentIntentId = session.getPaymentIntent();

            if (paymentIntentId != null) {
                return paymentIntentId;
            }

            Thread.sleep(5000);
        }
        return null;
    }

    private String waitForPaymentStatus(String paymentIntentId) throws InterruptedException, StripeException {
        for (int i = 0; i < 30; i++) { // Poll for up to 60 seconds
            PaymentIntent intent = PaymentIntent.retrieve(paymentIntentId);
            String status = intent.getStatus();

            if ("succeeded".equals(status) || "canceled".equals(status)) {
                return status;
            }

            Thread.sleep(2000);
        }
        return "timeout";
    }






    public PaymentResponse createPaymentIntent(PaymentRequest request) throws StripeException {
        // Step 1: Create Stripe PaymentIntent
        PaymentIntentCreateParams createParams = PaymentIntentCreateParams.builder()
                .setAmount(request.getAmount())
                .setCurrency(request.getCurrency())
                .setReceiptEmail(request.getEmail())
                .putMetadata("integration_check", "accept_a_payment")
                .putMetadata("receipt_id", request.getReceipt() != null ? request.getReceipt() : UUID.randomUUID().toString())
                .build();

        PaymentIntent paymentIntent = PaymentIntent.create(createParams);

        // Step 2: Save in MySQL
        PaymentInfo info = new PaymentInfo();
        info.setEmail(request.getEmail());
        info.setAmount(request.getAmount());
        info.setCurrency(request.getCurrency());
        info.setPaymentStatus(paymentIntent.getStatus());
        info.setStripePaymentIntentId(paymentIntent.getId());
        info.setPaymentDate(LocalDateTime.now());

        paymentInfoRepository.save(info);

        return new PaymentResponse(paymentIntent.getClientSecret(), paymentIntent.getStatus(), paymentIntent.getId());
    }

    public String getPaymentIntentStatus(String paymentIntentId) throws StripeException {
        PaymentIntent paymentIntent = PaymentIntent.retrieve(paymentIntentId);
        return paymentIntent.getStatus();
    }
}
