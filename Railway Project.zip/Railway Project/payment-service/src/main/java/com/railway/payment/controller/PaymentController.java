package com.railway.payment.controller;

import com.railway.payment.dto.PaymentRequest;
import com.railway.payment.dto.PaymentResponse;
import com.railway.payment.service.PaymentService;
import com.stripe.exception.StripeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/success")
    public String getSuccessStatus(){
        return "Successfull";
    }

    @GetMapping("/cancel")
    public String getFailedStatus(){
        return "Failed";
    }

    @PostMapping("/create")
    public PaymentResponse createPaymentIntent(@RequestBody PaymentRequest request) throws StripeException {
        return paymentService.createPaymentIntent(request);
    }

    @PostMapping("/pay")
    public String createCheckoutSession(@RequestBody PaymentRequest request) throws StripeException, InterruptedException {
        return paymentService.createCheckoutSession(request);
    }

    @GetMapping("/{paymentIntentId}")
    public String paymentIntentStatus(@PathVariable String paymentIntentId) throws StripeException {
        return paymentService.getPaymentIntentStatus(paymentIntentId);
    }

}
