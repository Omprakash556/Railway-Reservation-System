package com.railway.booking.service;

import com.railway.booking.entity.Booking;
import com.railway.booking.exception.*;
import com.railway.booking.external.PaymentServiceClient;
import com.railway.booking.external.TrainServiceClient;
import com.railway.booking.model.PaymentRequest;
import com.railway.booking.model.Station;
import com.railway.booking.model.Train;
import com.railway.booking.repository.BookingRepository;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class BookingService {

    private static final Logger logger = LoggerFactory.getLogger(BookingService.class);

    @Autowired
    private EmailService emailService;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private TrainServiceClient trainServiceClient;

    @Autowired
    private PaymentServiceClient paymentServiceClient;

    public Booking bookTicket(Booking booking, String email) {
        logger.info("Starting booking process for user: {}", email);
        Train train;
        try {
            train = trainServiceClient.getTrainById(booking.getTrainId());
        } catch (FeignException.NotFound e) {
            throw new TrainNotFoundException("Train not found with ID: " + booking.getTrainId());
        }

        if (train.getAvailableSeats() < booking.getSeatsBooked()) {
            throw new InvalidBookingException("Requested seats exceed available seats");
        }

        if (!train.getTravelDate().equals(booking.getTravelDate())) {
            throw new InvalidBookingException("Travel date mismatch with train schedule");
        }

        boolean sourceExists = train.getStationList().stream()
                .anyMatch(x -> x.getStationName().equalsIgnoreCase(booking.getSource()));
        boolean destinationExists = train.getStationList().stream()
                .anyMatch(x -> x.getStationName().equalsIgnoreCase(booking.getDestination()));

        if (!sourceExists || !destinationExists) {
            throw new InvalidBookingException("Invalid route: " + booking.getSource() + " to " + booking.getDestination());
        }

        double calculatedFare = 100;
        for (Station s : train.getStationList()) {
            if (s.getStationName().equalsIgnoreCase(booking.getSource())) calculatedFare = s.getFareTillThis();
            if (s.getStationName().equalsIgnoreCase(booking.getDestination())) {
                calculatedFare -= s.getFareTillThis();
                break;
            }
        }

        booking.setFare(Math.abs(calculatedFare));
        booking.setPnr(UUID.randomUUID().toString().substring(0, 8));
        booking.setTravelDate(train.getTravelDate());

        trainServiceClient.updateSeats(booking.getTrainId(), -booking.getSeatsBooked());

        PaymentRequest request = new PaymentRequest(Math.round(Math.abs(calculatedFare)) * 100, "inr", booking.getPnr(), email);
        String status;

        try {
            status = paymentServiceClient.createCheckoutSession(request);
            if (!status.equalsIgnoreCase("succeeded")) {
                throw new PaymentFailedException("Payment not completed successfully");
            }
        } catch (Exception e) {
            throw new PaymentFailedException("Payment failed: " + e.getMessage());
        }

        emailService.sendBookingConfirmation(email, booking.getPassengerName(), booking.getPnr(), status);
        booking.setStatus(status);

        return bookingRepository.save(booking);
    }

    public Optional<Booking> cancelTicket(String pnr, String email) {
        Optional<Booking> bookingOtp = bookingRepository.findByPnr(pnr);
        if (bookingOtp.isEmpty()) {
            throw new BookingNotFoundException("Booking not found with PNR: " + pnr);
        }

        Booking booking = bookingOtp.get();
        emailService.sendBookingCancellation(email, booking.getPassengerName(), booking.getPnr());
        trainServiceClient.updateSeats(booking.getTrainId(), booking.getSeatsBooked());
        bookingRepository.delete(booking);
        return Optional.of(booking);
    }

    public List<Booking> getAll() {
        return bookingRepository.findAll();
    }
}
