package com.railway.booking.controller;

import com.railway.booking.entity.Booking;
import com.railway.booking.service.BookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@Tag(name = "Booking Controller", description = "Book Ticket, Get all bookings, Cancel Ticket")
public class BookingController {

    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    @Autowired
    private BookingService bookingService;

    @PostMapping
    @Operation(summary = "API for book ticket")
    public ResponseEntity<Booking> book(@Valid @RequestBody Booking booking,
                                        @RequestHeader("X-User-Email") String email) {
        logger.info("Booking request received for user: {}", email);
        Booking booked = bookingService.bookTicket(booking, email);
        return ResponseEntity.ok(booked);
    }

    @GetMapping
    @Operation(summary = "API for get all bookings")
    public ResponseEntity<List<Booking>> getAllBookings() {
        logger.info("Fetching all bookings");
        return ResponseEntity.ok(bookingService.getAll());
    }

    @DeleteMapping("/pnr/{pnr}")
    @Operation(summary = "API for cancel ticket")
    public ResponseEntity<String> cancel(@PathVariable String pnr,
                                         @RequestHeader("X-User-Email") String email) {
        logger.info("Cancellation request for PNR: {} by user: {}", pnr, email);
        bookingService.cancelTicket(pnr, email);
        return ResponseEntity.ok("Booking cancelled for PNR: " + pnr);
    }
}
