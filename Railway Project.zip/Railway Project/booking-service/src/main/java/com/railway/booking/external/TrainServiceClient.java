package com.railway.booking.external;

import com.railway.booking.model.Train;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@FeignClient(name = "train-service")
public interface TrainServiceClient {
    @GetMapping("/api/trains/id/{id}")
    Train getTrainById(@PathVariable Long id);

    @PutMapping("api/trains/update-seats/{id}")
    Train updateSeats(@PathVariable Long id, @RequestParam int count);

    @GetMapping("api/trains/search")
    List<Train> getByRoute(@RequestParam String source, @RequestParam String destination, @RequestParam LocalDate date);

}
