package com.railway.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendBookingConfirmation(String toEmail, String passengerName, String pnr, String status) {
        String subject = "Booking Confirmation - Railway Reservation";
        String body = "Dear " + passengerName + ",\n\n" +
                "Your booking is confirmed. Your Ticket PNR is: " + pnr  +
                " with Payment status "+status + "\n\n" +
                "Thank you for choosing us.\n\nRailway Reservation System";
        sendEmail(toEmail, subject, body);
    }

    public void sendBookingCancellation(String toEmail, String passengerName, String pnr) {
        String subject = "Booking Cancellation - Railway Reservation";
        String body = "Dear " + passengerName + ",\n\n" +
                "Your booking with PNR " + pnr + " has been cancelled successfully.\n" +
                "We hope to serve you again.\n\nRailway Reservation System";

        sendEmail(toEmail, subject, body);
    }

    private void sendEmail(String toEmail, String subject, String body) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("no-reply@railwayapp.com"); // dummy sender
        message.setTo(toEmail);
        message.setSubject(subject);
        message.setText(body);
        mailSender.send(message);
    }
}

