package com.railway.booking;

//package com.railway.booking.service;

import com.railway.booking.entity.Booking;
import com.railway.booking.exception.*;
import com.railway.booking.external.PaymentServiceClient;
import com.railway.booking.external.TrainServiceClient;
import com.railway.booking.model.Station;
import com.railway.booking.model.Train;
import com.railway.booking.repository.BookingRepository;
import com.railway.booking.service.BookingService;
import com.railway.booking.service.EmailService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookingServiceTest {

    @InjectMocks
    private BookingService bookingService;

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private TrainServiceClient trainServiceClient;

    @Mock
    private PaymentServiceClient paymentServiceClient;

    @Mock
    private EmailService emailService;

    private Booking booking;
    private Train train;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        booking = new Booking();
        booking.setTrainId(1L);
        booking.setSeatsBooked(2);
        booking.setSource("Mumbai");
        booking.setDestination("Pune");
        booking.setTravelDate(LocalDate.now());
        booking.setPassengerName("Om Nema");

        Station mumbai = new Station();
        mumbai.setId(1L);
        mumbai.setStationName("Mumbai");
        mumbai.setStationCode("MUM");
        mumbai.setFareTillThis(0.0);

        Station pune = new Station();
        pune.setId(2L);
        pune.setStationName("Pune");
        pune.setStationCode("PUN");
        pune.setFareTillThis(200.0);

        train = new Train();
        train.setId(1L);
        train.setAvailableSeats(10);
        train.setTravelDate(LocalDate.now());
        train.setStationList(List.of(mumbai, pune));
    }

    @Test
    void testBookTicket_Success() {
        when(trainServiceClient.getTrainById(1L)).thenReturn(train);
        when(paymentServiceClient.createCheckoutSession(any())).thenReturn("succeeded");
        when(bookingRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        Booking result = bookingService.bookTicket(booking, "test@example.com");

        assertNotNull(result.getPnr());
        assertEquals("succeeded", result.getStatus());
        verify(trainServiceClient).updateSeats(1L, -2);
        verify(emailService).sendBookingConfirmation(eq("test@example.com"), eq("Om Nema"), anyString(), eq("succeeded"));
    }

    @Test
    void testBookTicket_InvalidRoute() {
        Station delhi = new Station();
        delhi.setStationName("Delhi");
        delhi.setFareTillThis(0.0);

        train.setStationList(List.of(delhi));
        when(trainServiceClient.getTrainById(1L)).thenReturn(train);

        assertThrows(InvalidBookingException.class, () -> bookingService.bookTicket(booking, "test@example.com"));
    }

    @Test
    void testCancelTicket_Success() {
        booking.setPnr("PNR123");
        when(bookingRepository.findByPnr("PNR123")).thenReturn(Optional.of(booking));

        Optional<Booking> result = bookingService.cancelTicket("PNR123", "test@example.com");

        assertTrue(result.isPresent());
        verify(emailService).sendBookingCancellation("test@example.com", "Om Nema", "PNR123");
        verify(trainServiceClient).updateSeats(1L, 2);
        verify(bookingRepository).delete(booking);
    }
}
