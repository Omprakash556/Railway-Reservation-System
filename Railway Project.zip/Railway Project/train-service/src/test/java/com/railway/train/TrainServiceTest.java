package com.railway.train;

import com.railway.train.entity.Train;
import com.railway.train.exception.ResourceNotFoundException;
import com.railway.train.external.StationServiceClient;
import com.railway.train.model.Station;
import com.railway.train.repository.TrainRepository;
import com.railway.train.service.TrainService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TrainServiceTest {

    @InjectMocks
    private TrainService trainService;

    @Mock
    private TrainRepository trainRepository;

    @Mock
    private StationServiceClient stationServiceClient;

    private Train train;

    @BeforeEach
    void setUp() {
        Station station1 = new Station(1L, "Mumbai", "BCT", 0);
        Station station2 = new Station(2L, "Delhi", "NDLS", 0);

        train = new Train();
        train.setId(1L);
        train.setTrainName("Rajdhani Express");
        train.setAvailableSeats(100);
        train.setTravelDate(LocalDate.now());
        train.setStationList(List.of(station1, station2));
    }

    @Test
    void testGetAllTrains() {
        when(trainRepository.findAll()).thenReturn(List.of(train));

        List<Train> result = trainService.getAllTrains();

        assertEquals(1, result.size());
        verify(trainRepository, times(1)).findAll();
    }

    @Test
    void testGetTrainById_Found() {
        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));

        Optional<Train> result = trainService.getTrainById(1L);

        assertTrue(result.isPresent());
        assertEquals("Rajdhani Express", result.get().getTrainName());
    }

    @Test
    void testGetTrainById_NotFound() {
        when(trainRepository.findById(2L)).thenReturn(Optional.empty());

        Optional<Train> result = trainService.getTrainById(2L);

        assertTrue(result.isEmpty());
    }

    @Test
    void testUpdateAvailableSeats_Success() {
        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));
        when(trainRepository.save(any())).thenReturn(train);

        Train updated = trainService.updateAvailableSeats(1L, -10);

        assertEquals(90, updated.getAvailableSeats());
    }

    @Test
    void testUpdateAvailableSeats_InsufficientSeats() {
        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));

        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                trainService.updateAvailableSeats(1L, -200));

        assertEquals("Not enough seats are available", ex.getMessage());
    }

    @Test
    void testDeleteTrain_Success() {
        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));

        trainService.deleteTrain(1L);

        verify(trainRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteTrain_NotFound() {
        when(trainRepository.findById(2L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> trainService.deleteTrain(2L));
    }

    @Test
    void testSearchTrain_NoMatch() {
        when(trainRepository.findAll()).thenReturn(List.of(train));

        assertThrows(ResourceNotFoundException.class, () ->
                trainService.searchTrain("XYZ", "ABC", LocalDate.now()));
    }
}

