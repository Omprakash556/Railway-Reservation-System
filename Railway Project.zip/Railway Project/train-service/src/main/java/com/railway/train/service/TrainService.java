package com.railway.train.service;

import com.railway.train.entity.Train;
import com.railway.train.exception.ResourceNotFoundException;
import com.railway.train.external.StationServiceClient;
import com.railway.train.model.Station;
import com.railway.train.repository.TrainRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TrainService {

    private static final Logger logger = LoggerFactory.getLogger(TrainService.class);

    @Autowired
    private StationServiceClient stationServiceClient;

    @Autowired
    private TrainRepository trainRepository;

    public Train saveTrain(Train train) {
        logger.debug("Saving train: {}", train.getTrainName());

        List<Station> fullStations = train.getStationList().stream()
                .map(s -> stationServiceClient.getStationById(s.getId())
                        .orElseThrow(() -> new ResourceNotFoundException("Station not found with ID: " + s.getId())))
                .toList();

        List<Station> stationStream = fullStations.stream().map(x -> {
            Station stationById = stationServiceClient.getStationById(x.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Station not found with ID: " + x.getId()));
            x.setStationCode(stationById.getStationCode());
            x.setStationName(stationById.getStationName());
            return x;
        }).toList();

        double baseFare = 0;
        for (Station s : stationStream) {
            baseFare += (int) (50 + (Math.random() * 100));
            s.setFareTillThis(baseFare);
        }
        stationStream.get(0).setFareTillThis(0);

        train.setStationList(stationStream);

        Train savedTrain = trainRepository.save(train);
        logger.info("Train saved successfully: {}", savedTrain.getTrainName());
        return savedTrain;
    }

    public List<Train> getAllTrains() {
        logger.debug("Fetching all trains from repository");
        return trainRepository.findAll();
    }

    public List<Train> searchTrain(String sourceCode, String destinationCode, LocalDate travelDate) {
        logger.debug("Searching trains from {} to {} on {}", sourceCode, destinationCode, travelDate);
        List<Train> allTrains = trainRepository.findAll();

        List<Train> matchingTrains = allTrains.stream()
                .filter(x -> x.getTravelDate().equals(travelDate))
                .filter(train -> {
                    List<Station> stations = train.getStationList();
                    int sourceIndex = -1;
                    int destinationIndex = -1;

                    for (int i = 0; i < stations.size(); i++) {
                        String code = stations.get(i).getStationCode();
                        if (code.equalsIgnoreCase(sourceCode)) sourceIndex = i;
                        if (code.equalsIgnoreCase(destinationCode)) destinationIndex = i;
                    }

                    return sourceIndex != -1 && destinationIndex != -1 && sourceIndex < destinationIndex;
                })
                .collect(Collectors.toList());

        if (matchingTrains.isEmpty()) {
            logger.warn("No trains found for route {} to {}", sourceCode, destinationCode);
            throw new ResourceNotFoundException("No trains found for this route: " + sourceCode + " to " + destinationCode);
        }

        return matchingTrains;
    }

    public Optional<Train> getTrainById(Long id) {
        logger.debug("Fetching train by ID: {}", id);
        return trainRepository.findById(id);
    }

    public void deleteTrain(Long id) {
        logger.info("Deleting train with ID: {}", id);
        Train train = trainRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Train not found with ID: " + id));
        trainRepository.deleteById(id);
    }

    public Train updateAvailableSeats(Long trainId, int count) {
        logger.debug("Updating available seats for train ID: {} with count: {}", trainId, count);
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new ResourceNotFoundException("Train not found with ID: " + trainId));

        int updatedSeats = train.getAvailableSeats() + count;
        if (updatedSeats < 0) {
            logger.error("Not enough seats available for train ID: {}", trainId);
            throw new RuntimeException("Not enough seats are available");
        }

        train.setAvailableSeats(updatedSeats);
        Train updatedTrain = trainRepository.save(train);
        logger.info("Updated seats for train ID: {} to {}", trainId, updatedSeats);
        return updatedTrain;

    }

//    public Train findTrainByName(String trainName){
//        return trainRepository.findByTrainName(trainName);
//    }

    public Train findByTrainName(String trainName) {
        return trainRepository.findByTrainName(trainName);
    }
}
