package com.railway.train.controller;

import com.railway.train.entity.Train;
import com.railway.train.exception.ResourceNotFoundException;
import com.railway.train.service.TrainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/trains")
@Tag(name = "Train Controller", description = "Add train, Get all train, Get train by route, Get train by id, Delete train by id")
public class TrainController {

    private static final Logger logger = LoggerFactory.getLogger(TrainController.class);

    @Autowired
    private TrainService trainService;

    @PostMapping
    @Operation(summary = "API for add train")
    public ResponseEntity<Train> addTrain(@RequestBody Train train) {
        logger.info("Adding new train: {}", train.getTrainName());
        return ResponseEntity.ok(trainService.saveTrain(train));
    }

    @GetMapping
    @Operation(summary = "API for get all train")
    public ResponseEntity<List<Train>> getAll() {
        logger.info("Fetching all trains");
        return ResponseEntity.ok(trainService.getAllTrains());
    }

    @GetMapping("/search")
    @Operation(summary = "API for get train by route")
    public ResponseEntity<List<Train>> getByRoute(@RequestParam String source, @RequestParam String destination, @RequestParam String date) {
        logger.info("Searching trains from {} to {} on {}", source, destination, date);
        return ResponseEntity.ok(trainService.searchTrain(source, destination, LocalDate.parse(date)));
    }

    @GetMapping("/id/{id}")
    @Operation(summary = "API for get train by id")
    public ResponseEntity<Train> getTrainById(@PathVariable Long id){
        logger.info("Fetching train by ID: {}", id);
        Train trainById = trainService.getTrainById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Train not found with ID: " + id));
        return ResponseEntity.ok(trainById);
    }

    @PutMapping("/update-seats/{id}")
    @Operation(summary = "API for update seat by id")
    public ResponseEntity<Train> updateSeats(@PathVariable Long id, @RequestParam int count){
        logger.info("Updating seats for train ID: {} with count: {}", id, count);
        Train updatedTrain = trainService.updateAvailableSeats(id, count);
        return ResponseEntity.ok(updatedTrain);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "API for delete train by id")
    public ResponseEntity<String> deleteTrainById(@PathVariable Long id){
        logger.info("Deleting train with ID: {}", id);
        Train trainById = trainService.getTrainById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Train not found with ID: " + id));
        trainService.deleteTrain(id);
        return ResponseEntity.ok("Train Deleted Successfully");
    }


    @GetMapping("/{trainName}")
    public ResponseEntity<Train> findByTrainName(@PathVariable String trainName){
        return ResponseEntity.ok(trainService.findByTrainName(trainName));
    }
}
